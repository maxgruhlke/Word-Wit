package edu.uwgb.debuggingclass_2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class profilesActivity extends AppCompatActivity {

    private LinearLayout profileList;
    private Button addProfileButton;
    private static final int REQUEST_ADD_PROFILE = 200;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profiles);

        profileList = findViewById(R.id.profileList);
        addProfileButton = findViewById(R.id.addProfileButton);

        loadProfiles();

        addProfileButton.setOnClickListener(v -> {
            Intent intent = new Intent(profilesActivity.this, AddProfileActivity.class);
            startActivityForResult(intent, REQUEST_ADD_PROFILE);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_ADD_PROFILE && resultCode == RESULT_OK && data != null) {

            String name = data.getStringExtra("profileName");
            String imageUriString = data.getStringExtra("profileImageUri");
            int rowIndex = data.getIntExtra("rowIndex", -1);

            if (rowIndex >= 0 && rowIndex < profileList.getChildCount()) {

                View row = profileList.getChildAt(rowIndex);

                TextView profileName = row.findViewById(R.id.profileName);
                ImageView avatar = row.findViewById(R.id.profileAvatar);

                profileName.setText(name);
                if (imageUriString != null) {
                    avatar.setImageURI(Uri.parse(imageUriString));
                }

                // Keep old score
                String[] oldTag = (String[]) row.getTag();
                String oldScore = oldTag[2];

                row.setTag(new String[]{name, imageUriString, oldScore});

            } else {
                addProfileRow(name, imageUriString, 0);
            }

            saveProfiles();
        }
    }

    private void addProfileRow(String name, String imageUri, int score) {

        View row = LayoutInflater.from(this).inflate(R.layout.profile_rows, profileList, false);

        TextView profileName = row.findViewById(R.id.profileName);
        ImageView avatar = row.findViewById(R.id.profileAvatar);
        ImageButton editBtn = row.findViewById(R.id.editProfile);
        ImageButton deleteBtn = row.findViewById(R.id.deleteProfile);

        profileName.setText(name);

        if (imageUri != null && !imageUri.isEmpty()) {
            avatar.setImageURI(Uri.parse(imageUri));
        }

        row.setTag(new String[]{name, imageUri, String.valueOf(score)});

        editBtn.setOnClickListener(v -> {
            String[] data = (String[]) row.getTag();

            Intent intent = new Intent(profilesActivity.this, AddProfileActivity.class);
            intent.putExtra("profileName", data[0]);
            intent.putExtra("profileImageUri", data[1]);
            intent.putExtra("rowIndex", profileList.indexOfChild(row));
            startActivityForResult(intent, REQUEST_ADD_PROFILE);
        });

        deleteBtn.setOnClickListener(v -> {
            profileList.removeView(row);
            saveProfiles();
        });

        profileList.addView(row);
    }

    private void saveProfiles() {

        SharedPreferences prefs = getSharedPreferences("profiles", MODE_PRIVATE);
        JSONArray arr = new JSONArray();

        for (int i = 0; i < profileList.getChildCount(); i++) {

            View row = profileList.getChildAt(i);
            String[] data = (String[]) row.getTag();

            try {
                JSONObject obj = new JSONObject();
                obj.put("name", data[0]);
                obj.put("imageUri", data[1]);
                obj.put("score", Integer.parseInt(data[2]));
                arr.put(obj);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        prefs.edit().putString("profiles_json", arr.toString()).apply();
    }

    private void loadProfiles() {

        SharedPreferences prefs = getSharedPreferences("profiles", MODE_PRIVATE);
        String jsonString = prefs.getString("profiles_json", null);

        if (jsonString == null) return;

        try {
            JSONArray arr = new JSONArray(jsonString);

            for (int i = 0; i < arr.length(); i++) {

                JSONObject obj = arr.getJSONObject(i);

                String name = obj.optString("name", "Unnamed");
                String uri = obj.optString("imageUri", null);
                int score = obj.optInt("score", 0);

                addProfileRow(name, uri, score);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_xml, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.item1: // Home
                startActivity(new Intent(this, Calculator.class));
                return true;

            case R.id.item2: // Leaderboard
                startActivity(new Intent(this, LeaderboardActivity.class));
                return true;

            case R.id.item3: // Settings
                startActivity(new Intent(this, SettingsActivity.class));
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

package edu.uwgb.debuggingclass_2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class GameActivity extends AppCompatActivity {

    private GridLayout gridLayout;
    private TextView[][] letterTiles = new TextView[6][5];
    private int currentRow = 0;
    private int currentCol = 0;
    private boolean gameOver = false;

    private Set<String> validWords = new HashSet<>();
    private List<String> answerList = new ArrayList<>();

    private EditText hiddenInput;
    private Button continueButton;

    private String targetWord;
    private int profileIndex = -1;
    private String mode = "practice"; // default
    private int pointsEarned = 0;
    private final HashMap<Character, Button> keyboard = new HashMap<>();



    //--------------------------------------------------------------------
    // LOAD ANSWERS FILE
    //--------------------------------------------------------------------
    private void loadAnswers() {
        try {
            InputStream is = getResources().openRawResource(R.raw.answers);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));

            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim().toUpperCase();
                if (line.length() == 5) answerList.add(line);
            }

            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //--------------------------------------------------------------------
    // ON CREATE
    //--------------------------------------------------------------------
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        // Read mode safely
        mode = getIntent().getStringExtra("mode");
        if (mode == null) mode = "practice";

        // ONLY daily mode uses profiles
        if ("daily".equals(mode)) {
            profileIndex = getIntent().getIntExtra("profile_index", -1);
        }

        gridLayout = findViewById(R.id.gridLayout);
        hiddenInput = findViewById(R.id.hiddenInput);
        continueButton = findViewById(R.id.continueButton);
        continueButton.setVisibility(View.GONE);

        loadAnswers();
        loadValidWords();
        initGrid();
        setupKeyboardButtons();

        // Pick target word
        if (!answerList.isEmpty()) {
            targetWord = answerList.get(new Random().nextInt(answerList.size()));
        } else {
            targetWord = "APPLE";
        }

        setupKeyboardInput();
    }

    //--------------------------------------------------------------------
    // OPTIONS MENU
    //--------------------------------------------------------------------
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_xml, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case R.id.item1: // Home
                startActivity(new Intent(this, Calculator.class));
                finish();
                return true;

            case R.id.item2: // Leaderboard
                startActivity(new Intent(this, LeaderboardActivity.class));
                return true;

            case R.id.item3: // Settings
                startActivity(new Intent(this, SettingsActivity.class));
                return true;
        }

        return super.onOptionsItemSelected(item);
    }
    private void setupKeyboardButtons() {

        int[] ids = {
                R.id.keyQ, R.id.keyW, R.id.keyE, R.id.keyR, R.id.keyT,
                R.id.keyY, R.id.keyU, R.id.keyI, R.id.keyO, R.id.keyP,
                R.id.keyA, R.id.keyS, R.id.keyD, R.id.keyF, R.id.keyG,
                R.id.keyH, R.id.keyJ, R.id.keyK, R.id.keyL,
                R.id.keyZ, R.id.keyX, R.id.keyC, R.id.keyV, R.id.keyB,
                R.id.keyN, R.id.keyM
        };

        String letters = "QWERTYUIOPASDFGHJKLZXCVBNM";

        for (int i = 0; i < ids.length; i++) {
            Button b = findViewById(ids[i]);
            char c = letters.charAt(i);
            keyboard.put(c, b);

            b.setOnClickListener(v -> {
                if (!gameOver && currentCol < 5) {
                    letterTiles[currentRow][currentCol].setText(String.valueOf(c));
                    currentCol++;
                }
            });
        }

        // ENTER
        findViewById(R.id.keyEnter).setOnClickListener(v -> {
            if (!gameOver) onEnter(v);
        });

        // DELETE
        findViewById(R.id.keyDel).setOnClickListener(v -> {
            if (!gameOver) onDelete(v);
        });
    }


    //--------------------------------------------------------------------
    // UPDATE PROFILE SCORE (DAILY ONLY)
    //--------------------------------------------------------------------
    private void updateProfileScore(boolean win, int attemptsUsed) {

        if (!"daily".equals(mode)) return;
        if (profileIndex == -1) return;

        SharedPreferences prefs = getSharedPreferences("profiles", MODE_PRIVATE);
        String jsonString = prefs.getString("profiles_json", null);

        if (jsonString == null) return;

        try {
            JSONArray arr = new JSONArray(jsonString);
            JSONObject profile = arr.getJSONObject(profileIndex);
            int score = profile.optInt("score", 0);

            if (win) {
                int base = 25;
                int attemptBonus = (6 - attemptsUsed) * 4;   // fewer attempts = more points

                pointsEarned = base + attemptBonus;

            } else {
                pointsEarned = 3; // Consolation prize
            }

            score += pointsEarned;
            if (score < 0) score = 0;

            profile.put("score", score);
            prefs.edit().putString("profiles_json", arr.toString()).apply();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    //--------------------------------------------------------------------
    // END GAME
    //--------------------------------------------------------------------
    private void endGame(boolean win) {
        gameOver = true;
        hiddenInput.setEnabled(false);

        // attemptsUsed = row index + 1
        int attemptsUsed = currentRow + 1;

        updateProfileScore(win, attemptsUsed);

        // Create popup dialog
        android.app.AlertDialog.Builder dialog = new android.app.AlertDialog.Builder(this);

        if (win) {
            dialog.setTitle("You Win!");
            dialog.setMessage(
                    "Correct Word: " + targetWord +
                            "\nAttempts Used: " + attemptsUsed +
                            "\n\nPoints Earned: +" + pointsEarned
            );
        } else {
            dialog.setTitle("You Lose!");
            dialog.setMessage(
                    "Correct Word: " + targetWord +
                            "\n\nBetter luck next time!" +
                            "\nPoints Earned: +" + pointsEarned
            );
        }

        dialog.setPositiveButton("Continue", (d, w) -> continueButton.performClick());
        dialog.setCancelable(false);
        dialog.show();

        continueButton.setVisibility(View.VISIBLE);
    }


    //--------------------------------------------------------------------
    // CONTINUE BUTTON
    //--------------------------------------------------------------------
    public void onContinue(View view) {

        if ("practice".equals(mode)) {
            Intent i = new Intent(GameActivity.this, GameActivity.class);
            i.putExtra("mode", "practice");
            startActivity(i);
            finish();
        } else {
            Intent i = new Intent(GameActivity.this, Calculator.class);
            startActivity(i);
            finish();
        }
    }

    //--------------------------------------------------------------------
    // INIT BOARD GRID
    //--------------------------------------------------------------------
    private void initGrid() {
        for (int row = 0; row < 6; row++) {
            for (int col = 0; col < 5; col++) {
                TextView tv = new TextView(this);
                tv.setText("");
                tv.setTextSize(24);
                tv.setGravity(android.view.Gravity.CENTER);
                tv.setBackgroundColor(Color.LTGRAY);

                GridLayout.LayoutParams params = new GridLayout.LayoutParams();
                params.width = 120;
                params.height = 120;
                params.rowSpec = GridLayout.spec(row);
                params.columnSpec = GridLayout.spec(col);
                params.setMargins(5, 5, 5, 5);

                tv.setLayoutParams(params);
                letterTiles[row][col] = tv;
                gridLayout.addView(tv);
            }
        }
    }

    //--------------------------------------------------------------------
    // LOAD VALID WORD LIST
    //--------------------------------------------------------------------
    private void loadValidWords() {
        try {
            InputStream is = getResources().openRawResource(R.raw.wordlist);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));

            String line;
            while ((line = reader.readLine()) != null) {
                validWords.add(line.trim().toUpperCase());
            }

            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //--------------------------------------------------------------------
    // KEYBOARD HANDLING
    //--------------------------------------------------------------------
    private void setupKeyboardInput() {
        hiddenInput.requestFocus();
        InputMethodManager imm =
                (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);

        imm.showSoftInput(hiddenInput, InputMethodManager.SHOW_IMPLICIT);

        hiddenInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (gameOver) return;
                if (s.length() == 0) return;

                char letter = s.charAt(0);

                if (Character.isLetter(letter) && currentCol < 5) {
                    letterTiles[currentRow][currentCol].setText(
                            String.valueOf(letter).toUpperCase()
                    );
                    currentCol++;
                }

                s.clear();
            }
        });

        hiddenInput.setOnKeyListener((v, keyCode, event) -> {
            if (gameOver) return true;

            if (event.getAction() == KeyEvent.ACTION_DOWN) {

                if (keyCode == KeyEvent.KEYCODE_DEL) {
                    onDelete(v);
                    return true;
                }

                if (keyCode == KeyEvent.KEYCODE_ENTER) {
                    onEnter(v);
                    return true;
                }
            }
            return false;
        });
    }

    //--------------------------------------------------------------------
    // DELETE KEY
    //--------------------------------------------------------------------
    public void onDelete(View view) {

        if (currentCol > 0) {
            currentCol--;
            letterTiles[currentRow][currentCol].setText("");
        }
    }

    //--------------------------------------------------------------------
    // ENTER KEY → CHECK WORD
    //--------------------------------------------------------------------
    public void onEnter(View view) {

        if (currentCol != 5) {
            Toast.makeText(this, "Not enough letters", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get the guessed word
        StringBuilder guessBuilder = new StringBuilder();
        for (int col = 0; col < 5; col++) {
            guessBuilder.append(letterTiles[currentRow][col].getText());
        }

        String guess = guessBuilder.toString().toUpperCase();

        // Validate the word
        if (!validWords.contains(guess)) {
            Toast.makeText(this, "Invalid word", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean[] used = new boolean[5];

        // FIRST PASS – GREENS
        for (int i = 0; i < 5; i++) {
            String g = guess.substring(i, i + 1);
            String t = targetWord.substring(i, i + 1);

            if (g.equals(t)) {
                letterTiles[currentRow][i].setBackgroundColor(Color.GREEN);
                used[i] = true;
            }
        }

        // SECOND PASS – YELLOWS
        for (int i = 0; i < 5; i++) {
            String g = guess.substring(i, i + 1);
            String t = targetWord.substring(i, i + 1);

            if (!g.equals(t)) {
                for (int j = 0; j < 5; j++) {
                    if (!used[j] &&
                            g.equals(targetWord.substring(j, j + 1))) {

                        letterTiles[currentRow][i]
                                .setBackgroundColor(Color.YELLOW);

                        used[j] = true;
                        break;
                    }
                }
            }
        }

        // GREY FOR NON-MATCHES
        for (int i = 0; i < 5; i++) {
            int bg = ((ColorDrawable) letterTiles[currentRow][i]
                    .getBackground()).getColor();

            if (bg != Color.GREEN && bg != Color.YELLOW) {
                letterTiles[currentRow][i]
                        .setBackgroundColor(Color.DKGRAY);
            }
        }

        // WIN
        if (guess.equals(targetWord)) {
            endGame(true);
            return;
        }

        updateKeyboardColors(guess); // update BEFORE moving down

        currentRow++;
        currentCol = 0;

        if (currentRow == 6) endGame(false);

    }

    private void updateKeyboardColors(String guess) {

        for (int i = 0; i < 5; i++) {
            char c = guess.charAt(i);
            Button key = keyboard.get(c);
            if (key == null) continue;

            int tileColor = ((ColorDrawable) letterTiles[currentRow][i]
                    .getBackground()).getColor();

            int GREEN = Color.GREEN;
            int YELLOW = Color.YELLOW;
            int GRAY = Color.DKGRAY;

            int current = ((ColorDrawable) key.getBackground()).getColor();

            if (tileColor == GREEN) {
                key.setBackgroundColor(GREEN);
            }
            else if (tileColor == YELLOW && current != GREEN) {
                key.setBackgroundColor(YELLOW);
            }
            else if (tileColor == GRAY && current != GREEN && current != YELLOW) {
                key.setBackgroundColor(GRAY);
            }
        }
    }

}

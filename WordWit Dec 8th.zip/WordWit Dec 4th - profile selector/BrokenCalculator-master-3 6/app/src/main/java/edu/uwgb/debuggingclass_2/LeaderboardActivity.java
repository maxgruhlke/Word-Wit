package edu.uwgb.debuggingclass_2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class LeaderboardActivity extends AppCompatActivity {

    private LinearLayout leaderboardList;

    // Helper profile model
    private static class ProfileEntry {
        String name;
        String imageUri;
        int score;

        ProfileEntry(String n, String img, int s) {
            name = n;
            imageUri = img;
            score = s;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboard);

        leaderboardList = findViewById(R.id.leaderboardList);

        loadLeaderboard();

        findViewById(R.id.scoreInfoButton).setOnClickListener(v -> showScoreInfo());
    }

    private void showScoreInfo() {
        android.app.AlertDialog.Builder dialog = new android.app.AlertDialog.Builder(this);
        dialog.setTitle("How Scoring Works");

        dialog.setMessage(
                "Scores in Daily Mode are calculated using:\n\n" +
                        "• Base Points: 25 points for winning\n" +
                        "• Attempt Bonus: More points for fewer attempts\n" +
                        "      Formula: (6 - attemptsUsed) × 4\n\n" +
                        "Examples:\n" +
                        "• Win in 1 attempt → 25 + (5×4) = 45 points\n" +
                        "• Win in 3 attempts → 25 + (3×4) = 37 points\n" +
                        "• Win in 6 attempts → 25 + (0×4) = 25 points\n\n" +
                        "If you lose:\n" +
                        "• You still earn 3 points as a consolation prize\n\n" +
                        "Your total score never goes below zero."
        );

        dialog.setPositiveButton("OK", null);
        dialog.show();
    }


    private void loadLeaderboard() {

        SharedPreferences prefs = getSharedPreferences("profiles", MODE_PRIVATE);
        String jsonString = prefs.getString("profiles_json", null);

        if (jsonString == null) return;

        try {
            JSONArray arr = new JSONArray(jsonString);

            ArrayList<ProfileEntry> profiles = new ArrayList<>();

            // Load profiles from JSON
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);

                String name = obj.optString("name", "Unnamed");
                String uri = obj.optString("imageUri", null);
                int score = obj.optInt("score", 0);

                profiles.add(new ProfileEntry(name, uri, score));
            }

            // Sort descending by score
            Collections.sort(profiles, (a, b) -> Integer.compare(b.score, a.score));

            // Add rows
            for (int i = 0; i < profiles.size(); i++) {
                addLeaderboardRow(i + 1, profiles.get(i));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void addLeaderboardRow(int rank, ProfileEntry entry) {

        View row = LayoutInflater.from(this)
                .inflate(R.layout.row_leaderboard, leaderboardList, false);

        TextView lbRank = row.findViewById(R.id.lbRank);
        TextView lbName = row.findViewById(R.id.lbName);
        TextView lbScore = row.findViewById(R.id.lbScore);
        ImageView lbAvatar = row.findViewById(R.id.lbAvatar);

        lbRank.setText(String.valueOf(rank));
        lbName.setText(entry.name);
        lbScore.setText(String.valueOf(entry.score));

        // Load image if exists
        if (entry.imageUri != null && !entry.imageUri.isEmpty()) {
            try {
                lbAvatar.setImageURI(Uri.parse(entry.imageUri));
            } catch (Exception ignored) {}
        }

        leaderboardList.addView(row);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_xml, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.item1: // Home
                startActivity(new Intent(this, Calculator.class));
                return true;

            case R.id.item2: // Leaderboard
                startActivity(new Intent(this, LeaderboardActivity.class));
                return true;

            case R.id.item3: // Settings
                startActivity(new Intent(this, SettingsActivity.class));
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

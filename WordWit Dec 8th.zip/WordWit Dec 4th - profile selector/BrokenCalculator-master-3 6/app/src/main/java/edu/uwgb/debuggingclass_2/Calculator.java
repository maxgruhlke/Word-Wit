package edu.uwgb.debuggingclass_2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;

public class Calculator extends AppCompatActivity {

    private TextView introText;
    private Button dailyButton, practiceButton, leaderboardButton, settingsButton, yesButton, noButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("WordWit");
        setContentView(R.layout.activity_home); // your main menu XML

        // Intro/tutorial text
        introText = findViewById(R.id.textView);
        yesButton = findViewById(R.id.yesButton);
        noButton = findViewById(R.id.noButton);

        // Menu buttons
        dailyButton = findViewById(R.id.dailyButton);
        practiceButton = findViewById(R.id.profileButton);
        leaderboardButton = findViewById(R.id.accessibilityButton);
        settingsButton = findViewById(R.id.aboutButton);

        // Wi-Fi check
        if (!isWifiConnected()) {
            Toast.makeText(this, "Wi-Fi is not connected!", Toast.LENGTH_LONG).show();
        }



        // Button click listeners
        dailyButton.setOnClickListener(v -> {
            Intent i = new Intent(Calculator.this, ProfilePickerActivity.class);
            startActivity(i);
        });

        practiceButton.setOnClickListener(v -> {
            Intent intent = new Intent(Calculator.this, GameActivity.class);
            intent.putExtra("mode", "practice");
            startActivity(intent);
        });

        leaderboardButton.setOnClickListener(v -> {
            Intent intent = new Intent(Calculator.this, LeaderboardActivity.class);
            startActivity(intent);
        });

        settingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(Calculator.this, SettingsActivity.class);
            startActivity(intent);
        });

        yesButton.setOnClickListener(v -> {
            Intent intent = new Intent(Calculator.this, SettingsActivity.class);
            startActivity(intent);
            hideTutorialPrompt();
        });

        noButton.setOnClickListener(v -> hideTutorialPrompt());
    }

    private void hideTutorialPrompt() {
        introText.setVisibility(View.GONE);
        yesButton.setVisibility(View.GONE);
        noButton.setVisibility(View.GONE);
    }

    private boolean isWifiConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo wifi = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        return wifi != null && wifi.isConnected();
    }

    // Menu handling
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_xml, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.item1: // Home
                Toast.makeText(this, "Home clicked", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.item2: // Leaderboard
                startActivity(new Intent(this, LeaderboardActivity.class));
                return true;

            case R.id.item3: // Settings
                startActivity(new Intent(this, SettingsActivity.class));
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

package edu.uwgb.debuggingclass_2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class ProfilePickerActivity extends AppCompatActivity {

    private LinearLayout profileList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_picker);

        profileList = findViewById(R.id.profileList);
        Button addProfileButton = findViewById(R.id.addProfileButton);

        loadProfiles();

        addProfileButton.setOnClickListener(v -> {
            Intent i = new Intent(ProfilePickerActivity.this, AddProfileActivity.class);
            startActivityForResult(i, 200);
        });
    }

    private void loadProfiles() {
        SharedPreferences prefs = getSharedPreferences("profiles", MODE_PRIVATE);
        String jsonString = prefs.getString("profiles_json", null);

        if (jsonString == null) return;

        try {
            JSONArray arr = new JSONArray(jsonString);

            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);

                String name = obj.optString("name", "Unnamed");
                String uri = obj.optString("imageUri", null);

                addProfileRow(name, uri, i);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void addProfileRow(String name, String imageUri, int index) {

        View row = LayoutInflater.from(this).inflate(R.layout.profile_row_picker, profileList, false);

        TextView profileName = row.findViewById(R.id.profileName);
        ImageView avatar = row.findViewById(R.id.profileAvatar);

        profileName.setText(name);

        if (imageUri != null && !imageUri.isEmpty()) {
            avatar.setImageURI(Uri.parse(imageUri));
            avatar.setTag(imageUri);
        } else {
            avatar.setTag(null);
        }

        row.setOnClickListener(v -> {
            Intent i = new Intent(ProfilePickerActivity.this, GameActivity.class);
            i.putExtra("mode", "daily");
            i.putExtra("profile_index", index);
            startActivity(i);
            finish();
        });

        profileList.addView(row);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 200 && resultCode == RESULT_OK && data != null) {

            String name = data.getStringExtra("profileName");
            String imageUri = data.getStringExtra("profileImageUri");

            addProfileRow(name, imageUri, profileList.getChildCount());

            saveProfiles(); // <-- FIX!
        }
    }


    private void saveProfiles() {
        SharedPreferences prefs = getSharedPreferences("profiles", MODE_PRIVATE);
        JSONArray arr = new JSONArray();

        for (int i = 0; i < profileList.getChildCount(); i++) {
            View row = profileList.getChildAt(i);

            TextView nameView = row.findViewById(R.id.profileName);
            ImageView avatarView = row.findViewById(R.id.profileAvatar);

            String name = nameView.getText().toString();
            String uri = (String) avatarView.getTag(); // We will store URI in tag

            try {
                JSONObject obj = new JSONObject();
                obj.put("name", name);
                obj.put("imageUri", uri);
                arr.put(obj);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        prefs.edit().putString("profiles_json", arr.toString()).apply();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_xml, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.item1: // Home
                startActivity(new Intent(this, Calculator.class));
                return true;

            case R.id.item2: // Leaderboard
                startActivity(new Intent(this, LeaderboardActivity.class));
                return true;

            case R.id.item3: // Settings
                startActivity(new Intent(this, SettingsActivity.class));
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}


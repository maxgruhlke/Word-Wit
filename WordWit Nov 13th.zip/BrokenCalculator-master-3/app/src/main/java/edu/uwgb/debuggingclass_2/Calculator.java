package edu.uwgb.debuggingclass_2;
import android.content.Intent;
import android.net.Uri; /*Needed for web links*/
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.transition.Scene; /* Scene & TransitionManager work together. Both are needed if one is needed*/
import android.transition.TransitionManager;
import android.view.Menu; /*Menu, MenuInflater, & MenuItem are required*/
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;


public class Calculator extends AppCompatActivity {

    /*
    There are errors in this code, that will cause various issues
    Your goal is to get the calculator working as good as possible
    1. Make sure all Numbers input the proper numbers
    2. Make sure the proper operation is applied when = is hit
    3. Think about as many edge cases as you can, can you break the calculator and then fix it?
    4. Can you make it ignore leading 0's if a bunch of 0's are pressed?
    5. BONUS: Can you get the current operation to display somewhere?
     */

    private String currentValue = "";
    private String lastValue = "";
    private String operation = "";

    private Scene scene1;
    private Scene scene2;
    private Scene scene3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator3);
        scene1 = Scene.getSceneForLayout((ViewGroup)findViewById(R.id.rootContainer), R.layout.activity_calculator3,this);
        scene2 = Scene.getSceneForLayout((ViewGroup)findViewById(R.id.rootContainer), R.layout.activity_calculator2,this);
        scene3 = Scene.getSceneForLayout((ViewGroup)findViewById(R.id.rootContainer), R.layout.activity_calculator,this);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_xml, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId())

        {
            case R.id.item1:
                Toast.makeText(Calculator.this,"item1" , Toast.LENGTH_LONG).show();

        }
        return true;
    }

    private void insertDecimal(String num) {

        currentValue = currentValue + num;
        setDisplay(currentValue);
    }
    public void onDecimal(View view) {
        insertDecimal(".");
    }


    public void gotopage(View view){
        Intent openURL = new Intent(android.content.Intent.ACTION_VIEW);
        openURL.setData(Uri.parse("https://www.dndbeyond.com"));
        startActivity(openURL);
    }
    private void insertNumber(int num) {
        currentValue = currentValue + Integer.toString(num);
        setDisplay(currentValue);
    }

    private void setDisplay(String str) {
        TextView view = (TextView)findViewById(R.id.displayValue);
        view.setText(str);
    }

    public void onNum1(View view) {
        insertNumber(1);
    }

    public void onNum2(View view) {
        insertNumber(2);
    }
    public void Num1(View view) {
        TransitionManager.go(scene2);
    }

    public void Num2(View view) {
        TransitionManager.go(scene1);
    }
    public void Num4(View view) {
        TransitionManager.go(scene3);
    }

    public void onNum3(View view) {
        insertNumber(3);
    }


    public void onNum4(View view) {
        insertNumber(4);
    }

    public void onNum5(View view) {
        insertNumber(5);
    }

    public void onNum6(View view) {
        insertNumber(6);
    }

    public void onNum7(View view) {
        insertNumber(7);
    }

    public void onNum8(View view) {
        insertNumber(8);
    }

    public void onNum9(View view) {
        insertNumber(9);
    }

    public void onNum0(View view) {

        if(currentValue.equals("")){}
        else{insertNumber(0);
        }
    }

    public void onAdd(View view) {
        lastValue = currentValue;
        currentValue = "";
        setDisplay("+");
        operation = "add";
    }

    public void onSubtract(View view) {
        lastValue = currentValue;
        currentValue = "";
        setDisplay("-");
        operation = "subtract";
    }

    public void onMultiply(View view) {
        lastValue = currentValue;
        currentValue = "";
        setDisplay("*");
        operation = "multiply";
    }

    public void onDivide(View view) {
        lastValue = currentValue;
        currentValue = "";
        setDisplay("/");
        operation = "divide";
    }

    public void onEquals(View view) {
        if(lastValue.length() > 0 && currentValue.length() > 0) {
            double val1 = Double.parseDouble(lastValue);
            double val2 = Double.parseDouble(currentValue);

            double newValue = 0;
            switch (operation) {
                case "add":
                    newValue = val1 + val2;
                    break;
                case "subtract":
                    newValue = val1 - val2;
                    break;
                case "multiply":
                    newValue = val1 * val2;
                    break;
                case "divide":
                    newValue = val1 / val2;
            }
            currentValue = "";
            setDisplay(Double.toString(newValue));
        }
    }

    public void onClear(View view) {
        operation = "";
        currentValue = "";
        lastValue = "";
        setDisplay((lastValue));
    }
}

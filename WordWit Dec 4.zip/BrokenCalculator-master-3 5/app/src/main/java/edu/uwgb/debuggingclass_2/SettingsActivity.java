package edu.uwgb.debuggingclass_2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class SettingsActivity extends AppCompatActivity {

    private TextView wifiStatusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        wifiStatusText = findViewById(R.id.wifiStatusText);

        // Check Wi-Fi status
        if (isWifiConnected()) {
            wifiStatusText.setText("Wi-Fi is connected ✅");
        } else {
            wifiStatusText.setText("Wi-Fi is not connected ❌");
        }

        // Wire up the Profiles button
        Button profileButton = findViewById(R.id.profileButton);
        profileButton.setOnClickListener(v -> {
            Intent intent = new Intent(SettingsActivity.this, profilesActivity.class);
            startActivity(intent);
        });
    }

    private boolean isWifiConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            NetworkInfo wifi = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
            return wifi != null && wifi.isConnected();
        }
        return false;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_xml, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.item1: // Home
                Intent intentHome = new Intent(SettingsActivity.this, Calculator.class);
                startActivity(intentHome);
                return true;

            case R.id.item2: // Leaderboard
                Toast.makeText(this, "Leaderboard", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.item3: // Settings
                Toast.makeText(this, "Settings", Toast.LENGTH_SHORT).show();
                return true;

        }
        return super.onOptionsItemSelected(item);
    }
}

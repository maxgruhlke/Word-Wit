package edu.uwgb.debuggingclass_2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

public class profilesActivity extends AppCompatActivity {

    private LinearLayout profileList;
    private Button addProfileButton;
    private static final int REQUEST_ADD_PROFILE = 200;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profiles);

        profileList = findViewById(R.id.profileList);
        addProfileButton = findViewById(R.id.addProfileButton);

        // Load saved profiles when screen opens
        loadProfiles();

        // Launch AddProfileActivity when button is clicked
        addProfileButton.setOnClickListener(v -> {
            Intent intent = new Intent(profilesActivity.this, AddProfileActivity.class);
            startActivityForResult(intent, REQUEST_ADD_PROFILE);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ADD_PROFILE && resultCode == RESULT_OK && data != null) {
            String name = data.getStringExtra("profileName");
            String imageUriString = data.getStringExtra("profileImageUri");
            int rowIndex = data.getIntExtra("rowIndex", -1);

            if (rowIndex >= 0 && rowIndex < profileList.getChildCount()) {
                // Update existing row safely
                View row = profileList.getChildAt(rowIndex);
                TextView profileName = row.findViewById(R.id.profileName);
                ImageView avatar = row.findViewById(R.id.profileAvatar);

                profileName.setText(name != null ? name : "Unnamed");
                if (imageUriString != null && !imageUriString.isEmpty()) {
                    avatar.setImageURI(Uri.parse(imageUriString));
                }

                // Update tag for future edits
                row.setTag(new String[]{name, imageUriString});
            } else {
                // Add new row
                addProfileRow(name, imageUriString);
            }

            // Save after any add/edit
            saveProfiles();
        }
    }

    private void addProfileRow(String name, String imageUriString) {
        View row = LayoutInflater.from(this).inflate(R.layout.profile_rows, profileList, false);

        TextView profileName = row.findViewById(R.id.profileName);
        ImageView avatar = row.findViewById(R.id.profileAvatar);
        ImageButton editBtn = row.findViewById(R.id.editProfile);
        ImageButton deleteBtn = row.findViewById(R.id.deleteProfile);

        profileName.setText(name != null ? name : "Unnamed");

        if (imageUriString != null && !imageUriString.isEmpty()) {
            avatar.setImageURI(Uri.parse(imageUriString));
        }

        // Store current data in the row itself
        row.setTag(new String[]{name, imageUriString});

        // Edit profile: launch AddProfileActivity with current data
        editBtn.setOnClickListener(v -> {
            String[] data = (String[]) row.getTag();
            Intent intent = new Intent(profilesActivity.this, AddProfileActivity.class);
            if (data != null) {
                intent.putExtra("profileName", data[0]);
                intent.putExtra("profileImageUri", data[1]);
            }
            intent.putExtra("rowIndex", profileList.indexOfChild(row));
            startActivityForResult(intent, REQUEST_ADD_PROFILE);
        });

        // Delete profile
        deleteBtn.setOnClickListener(v -> {
            profileList.removeView(row);
            saveProfiles(); // Save after deletion
        });

        profileList.addView(row);
    }

    // Save all profiles to SharedPreferences
    private void saveProfiles() {
        SharedPreferences prefs = getSharedPreferences("profiles", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        JSONArray jsonArray = new JSONArray();
        for (int i = 0; i < profileList.getChildCount(); i++) {
            View row = profileList.getChildAt(i);
            TextView profileName = row.findViewById(R.id.profileName);
            String[] data = (String[]) row.getTag();

            JSONObject obj = new JSONObject();
            try {
                obj.put("name", profileName.getText().toString());
                obj.put("imageUri", data != null ? data[1] : null);
            } catch (Exception e) {
                e.printStackTrace();
            }
            jsonArray.put(obj);
        }

        editor.putString("profiles_json", jsonArray.toString());
        editor.apply();
    }

    // Load saved profiles from SharedPreferences
    private void loadProfiles() {
        SharedPreferences prefs = getSharedPreferences("profiles", MODE_PRIVATE);
        String jsonString = prefs.getString("profiles_json", null);

        if (jsonString != null) {
            try {
                JSONArray jsonArray = new JSONArray(jsonString);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject obj = jsonArray.getJSONObject(i);
                    String name = obj.optString("name", "Unnamed");
                    String imageUri = obj.optString("imageUri", null);
                    addProfileRow(name, imageUri);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

package edu.uwgb.debuggingclass_2;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class AddProfileActivity extends AppCompatActivity {

    private static final int PICK_IMAGE = 100;
    private EditText nameInput;
    private ImageView profileImage;
    private Uri imageUri;
    private int rowIndex = -1; // track which row is being edited

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_profile);

        nameInput = findViewById(R.id.nameInput);
        profileImage = findViewById(R.id.profileImage);
        Button chooseImageButton = findViewById(R.id.chooseImageButton);
        Button saveButton = findViewById(R.id.saveButton);

        // Pre-fill if editing
        Intent intent = getIntent();
        if (intent != null) {
            String existingName = intent.getStringExtra("profileName");
            if (existingName != null) {
                nameInput.setText(existingName);
            }
            String uriString = intent.getStringExtra("profileImageUri");
            if (uriString != null && !uriString.isEmpty()) {
                try {
                    Uri uri = Uri.parse(uriString);
                    profileImage.setImageURI(uri);
                    imageUri = uri;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            rowIndex = intent.getIntExtra("rowIndex", -1);
        }

        // Save profile
        saveButton.setOnClickListener(v -> {
            String name = nameInput.getText().toString();
            Intent result = new Intent();
            result.putExtra("profileName", name);
            if (imageUri != null) {
                result.putExtra("profileImageUri", imageUri.toString());
            }
            if (rowIndex >= 0) {
                result.putExtra("rowIndex", rowIndex);
            }
            setResult(Activity.RESULT_OK, result);
            finish();
        });

        // Choose image using ACTION_OPEN_DOCUMENT (persistable access)
        chooseImageButton.setOnClickListener(v -> {
            Intent openDocIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            openDocIntent.addCategory(Intent.CATEGORY_OPENABLE);
            openDocIntent.setType("image/*");
            // Allow persistable read access
            openDocIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(openDocIntent, PICK_IMAGE);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            imageUri = data.getData();
            if (imageUri != null) {
                try {
                    // Persist permission so URI works later
                    final int takeFlags = data.getFlags()
                            & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    getContentResolver().takePersistableUriPermission(imageUri, takeFlags);

                    profileImage.setImageURI(imageUri);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_xml, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.item1: // Home
                startActivity(new Intent(this, Calculator.class));
                return true;

            case R.id.item2: // Leaderboard
                startActivity(new Intent(this, LeaderboardActivity.class));
                return true;

            case R.id.item3: // Settings
                startActivity(new Intent(this, SettingsActivity.class));
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

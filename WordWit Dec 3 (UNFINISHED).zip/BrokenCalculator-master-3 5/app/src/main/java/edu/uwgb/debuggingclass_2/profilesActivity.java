package edu.uwgb.debuggingclass_2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ProfilesActivity extends AppCompatActivity {

    private LinearLayout profileList;
    private Button addProfileButton;
    private int profileCounter = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profiles);

        profileList = findViewById(R.id.profileList);
        addProfileButton = findViewById(R.id.addProfileButton);

        addProfileButton.setOnClickListener(v -> addProfileRow("Profile " + profileCounter++));
    }

    private void addProfileRow(String name) {
        View row = LayoutInflater.from(this).inflate(R.layout.profile_rows, profileList, false);

        TextView profileName = row.findViewById(R.id.profileName);
        ImageButton editBtn = row.findViewById(R.id.editProfile);
        ImageButton deleteBtn = row.findViewById(R.id.deleteProfile);

        profileName.setText(name);

        editBtn.setOnClickListener(v -> profileName.setText(name + " (edited)"));
        deleteBtn.setOnClickListener(v -> profileList.removeView(row));

        profileList.addView(row);
    }
}

package edu.uwgb.debuggingclass_2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

public class ProfilePickerActivity extends AppCompatActivity {

    private LinearLayout profileList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_picker);

        profileList = findViewById(R.id.profileList);

        loadProfiles();
    }

    private void loadProfiles() {
        SharedPreferences prefs = getSharedPreferences("profiles", MODE_PRIVATE);
        String jsonString = prefs.getString("profiles_json", null);

        if (jsonString == null) return;

        try {
            JSONArray arr = new JSONArray(jsonString);

            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);

                String name = obj.optString("name", "Unnamed");
                String uri = obj.optString("imageUri", null);

                addProfileRow(name, uri, i);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void addProfileRow(String name, String imageUri, int index) {
        View row = LayoutInflater.from(this).inflate(R.layout.profile_row_picker, profileList, false);

        TextView profileName = row.findViewById(R.id.profileName);
        ImageView avatar = row.findViewById(R.id.profileAvatar);

        profileName.setText(name);

        if (imageUri != null && !imageUri.isEmpty()) {
            avatar.setImageURI(Uri.parse(imageUri));
        }

        // Clicking a profile → Start Daily Game
        row.setOnClickListener(v -> {
            Intent i = new Intent(ProfilePickerActivity.this, GameActivity.class);
            i.putExtra("mode", "daily");
            i.putExtra("profile_index", index);
            startActivity(i);
            finish();
        });

        profileList.addView(row);
    }
}


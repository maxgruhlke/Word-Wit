package edu.uwgb.debuggingclass_2;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class GameActivity extends AppCompatActivity {

    private GridLayout gridLayout;
    private TextView[][] letterTiles = new TextView[6][5];
    private int currentRow = 0;
    private int currentCol = 0;
    private boolean gameOver = false;

    private Set<String> validWords = new HashSet<>();
    private EditText hiddenInput;
    private Button continueButton;

    private List<String> answerList = new ArrayList<>();
    private String targetWord; // <-- FIXED (initialized later)

    private void loadAnswers() {
        try {
            InputStream is = getResources().openRawResource(R.raw.answers);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));

            String line;
            while ((line = reader.readLine()) != null) {
                answerList.add(line.trim().toUpperCase());
            }

            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        gridLayout = findViewById(R.id.gridLayout);
        hiddenInput = findViewById(R.id.hiddenInput);
        continueButton = findViewById(R.id.continueButton);

        continueButton.setVisibility(View.GONE);

        // Load answers FIRST
        loadAnswers();

        // FIX: Now we choose a random answer correctly
        targetWord = answerList.get(new Random().nextInt(answerList.size()));

        initGrid();
        loadValidWords();
        setupKeyboardInput();
    }


    private void endGame(boolean win) {
        gameOver = true;
        hiddenInput.setEnabled(false);

        if (win) {
            Toast.makeText(this, "You Win!", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "You Lose! Word was: " + targetWord, Toast.LENGTH_LONG).show();
        }

        continueButton.setVisibility(View.VISIBLE);
    }

    public void onContinue(View view) {
        Intent i = new Intent(GameActivity.this, Calculator.class);
        startActivity(i);
        finish();
    }

    private void initGrid() {
        for (int row = 0; row < 6; row++) {
            for (int col = 0; col < 5; col++) {
                TextView tv = new TextView(this);
                tv.setText("");
                tv.setTextSize(24);
                tv.setGravity(android.view.Gravity.CENTER);
                tv.setBackgroundColor(Color.LTGRAY);
                tv.setTextColor(Color.BLACK);
                tv.setId(View.generateViewId());

                GridLayout.LayoutParams params = new GridLayout.LayoutParams();
                params.width = 120;
                params.height = 120;
                params.rowSpec = GridLayout.spec(row);
                params.columnSpec = GridLayout.spec(col);
                params.setMargins(5, 5, 5, 5);

                tv.setLayoutParams(params);
                letterTiles[row][col] = tv;
                gridLayout.addView(tv);
            }
        }
    }

    private void loadValidWords() {
        try {
            InputStream is = getResources().openRawResource(R.raw.wordlist);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));

            String line;
            while ((line = reader.readLine()) != null) {
                validWords.add(line.trim().toUpperCase());
            }

            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to load words", Toast.LENGTH_SHORT).show();
        }
    }


    private void setupKeyboardInput() {
        hiddenInput.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.showSoftInput(hiddenInput, InputMethodManager.SHOW_IMPLICIT);

        hiddenInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                if (gameOver) return;
                if (s.length() == 0) return;

                char letter = s.charAt(0);
                if (Character.isLetter(letter)) {
                    if (currentCol < 5 && currentRow < 6) {
                        letterTiles[currentRow][currentCol].setText(
                                String.valueOf(letter).toUpperCase()
                        );
                        currentCol++;
                    }
                }
                s.clear();
            }
        });

        hiddenInput.setOnKeyListener((v, keyCode, event) -> {
            if (gameOver) return true;

            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                if (keyCode == KeyEvent.KEYCODE_DEL) {
                    onDelete(v);
                    return true;
                } else if (keyCode == KeyEvent.KEYCODE_ENTER) {
                    onEnter(v);
                    return true;
                }
            }
            return false;
        });
    }

    public void onDelete(View view) {
        if (gameOver) return;

        if (currentCol > 0 && currentRow < 6) {
            currentCol--;
            letterTiles[currentRow][currentCol].setText("");
        }
    }

    public void onEnter(View view) {
        if (gameOver) return;

        if (currentCol != 5) {
            Toast.makeText(this, "Not enough letters", Toast.LENGTH_SHORT).show();
            return;
        }

        StringBuilder guessBuilder = new StringBuilder();
        for (int col = 0; col < 5; col++) {
            guessBuilder.append(letterTiles[currentRow][col].getText().toString());
        }
        String guess = guessBuilder.toString().toUpperCase();

        if (!validWords.contains(guess)) {
            Toast.makeText(this, "Invalid word", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean[] targetUsed = new boolean[5];

        for (int i = 0; i < 5; i++) {
            String c = guess.substring(i, i + 1);
            if (c.equals(targetWord.substring(i, i + 1))) {
                letterTiles[currentRow][i].setBackgroundColor(Color.GREEN);
                targetUsed[i] = true;
            }
        }

        for (int i = 0; i < 5; i++) {
            String c = guess.substring(i, i + 1);
            if (!c.equals(targetWord.substring(i, i + 1))) {
                for (int j = 0; j < 5; j++) {
                    if (!targetUsed[j] && c.equals(targetWord.substring(j, j + 1))) {
                        letterTiles[currentRow][i].setBackgroundColor(Color.YELLOW);
                        targetUsed[j] = true;
                        break;
                    }
                }
            }
        }

        for (int i = 0; i < 5; i++) {
            int bg = ((ColorDrawable) letterTiles[currentRow][i].getBackground()).getColor();
            if (bg != Color.GREEN && bg != Color.YELLOW) {
                letterTiles[currentRow][i].setBackgroundColor(Color.DKGRAY);
            }
        }

        if (guess.equals(targetWord)) {
            endGame(true);
            return;
        }

        currentRow++;
        currentCol = 0;

        if (currentRow == 6) {
            endGame(false);
        }
    }
}
